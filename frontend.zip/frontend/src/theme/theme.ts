import { createTheme } from '@mui/material/styles'

const theme = createTheme({
  shape: { borderRadius: 10 },
  components: {
    MuiAlert: {
      styleOverrides: {
        root: { borderRadius: 10 },
      },
    },
    MuiSnackbar: {
      styleOverrides: {
        root: { zIndex: 1301 }, // above drawers
      },
    },
  },
})

export default theme
