// F:\medical-inventory\frontend\src\pages\Inventory\ItemForm.tsx
import { Drawer, Stack, TextField, Button, Typography } from '@mui/material'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { itemSchema } from '../../lib/validators'
import { z } from 'zod'
import React from 'react'

export type ItemFormValues = z.infer<typeof itemSchema>

export default function ItemForm({
  open, initial, onClose, onSubmit
}: {
  open: boolean
  initial?: Partial<ItemFormValues> | null
  onClose: () => void
  onSubmit: (values: ItemFormValues) => void
}) {
  // YYYY-MM-DD for today's date (used to block past expiries; remove if not needed)
  const today = React.useMemo(() => new Date().toISOString().slice(0, 10), [])

  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } =
    useForm<ItemFormValues>({
      resolver: zodResolver(itemSchema),
      defaultValues: {
        name: initial?.name ?? '',
        brand: (initial?.brand as any) ?? '',
        // batch_no: REMOVED
        expiry_date: (initial?.expiry_date as any) ?? '',   // expects "YYYY-MM-DD"
        mrp: Number(initial?.mrp ?? 0),
        stock: Number(initial?.stock ?? 0),
      }
    })

  // reset when `initial` changes
  React.useEffect(() => {
    reset({
      name: initial?.name ?? '',
      brand: (initial?.brand as any) ?? '',
      // batch_no: REMOVED
      expiry_date: (initial?.expiry_date as any) ?? '',
      mrp: Number(initial?.mrp ?? 0),
      stock: Number(initial?.stock ?? 0),
    })
  }, [initial, reset])

  return (
    <Drawer anchor="right" open={open} onClose={onClose} PaperProps={{ sx: { width: { xs: '100%', sm: 420 } } }}>
      <form onSubmit={handleSubmit(onSubmit)}>
        <Stack gap={2} p={3}>
          <Typography variant="h6">{initial?.name ? 'Edit Item' : 'Add Item'}</Typography>

          <TextField
            label="Name"
            {...register('name')}
            error={!!errors.name}
            helperText={errors.name?.message}
          />
          <TextField label="Brand" {...register('brand')} />

          {/* ✅ Native calendar picker, value = "YYYY-MM-DD" */}
          <TextField
            label="Expiry"
            type="date"
            {...register('expiry_date')}
            InputLabelProps={{ shrink: true }}
            inputProps={{ min: today }}           // block past dates (optional)
            error={!!errors.expiry_date}
            helperText={errors.expiry_date?.message || 'Format: YYYY-MM-DD'}
          />

          <TextField
            label="MRP"
            type="number"
            inputProps={{ step: 'any' }}
            {...register('mrp', { valueAsNumber: true })}
            error={!!errors.mrp}
            helperText={errors.mrp?.message}
          />
          <TextField
            label="Stock"
            type="number"
            {...register('stock', { valueAsNumber: true })}
            error={!!errors.stock}
            helperText={errors.stock?.message}
          />

          <Stack direction="row" gap={1} justifyContent="flex-end">
            <Button onClick={onClose}>Cancel</Button>
            <Button type="submit" variant="contained" disabled={isSubmitting}>Save</Button>
          </Stack>
        </Stack>
      </form>
    </Drawer>
  )
}
