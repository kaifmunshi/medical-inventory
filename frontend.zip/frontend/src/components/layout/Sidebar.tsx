import { Box, List, ListItemButton, ListItemIcon, ListItemText, Typography } from '@mui/material'
import { Inventory2, PointOfSale, AssignmentReturn, SwapHoriz, BarChart, Settings, Dashboard } from '@mui/icons-material'
import { NavLink, useLocation } from 'react-router-dom'


const links = [
{ to: '/', label: 'Dashboard', icon: <Dashboard /> },
{ to: '/inventory', label: 'Inventory', icon: <Inventory2 /> },
{ to: '/billing', label: 'Billing', icon: <PointOfSale /> },
{ to: '/returns', label: 'Returns', icon: <AssignmentReturn /> },
{ to: '/exchange', label: 'Exchange', icon: <SwapHoriz /> },
{ to: '/reports', label: 'Reports', icon: <BarChart /> },
{ to: '/settings', label: 'Settings', icon: <Settings /> },
]


export default function Sidebar() {
const { pathname } = useLocation()
return (
<Box width={240} bgcolor="#fafafa" borderRight="1px solid #eee" p={1}>
<Typography variant="h6" px={1} py={2}>
{import.meta.env.VITE_APP_NAME || 'Medical Inventory'}
</Typography>
<List>
{links.map(link => {
const active = pathname === link.to
return (
<ListItemButton key={link.to} component={NavLink} to={link.to} selected={active}>
<ListItemIcon>{link.icon}</ListItemIcon>
<ListItemText primary={link.label} />
</ListItemButton>
)
})}
</List>
</Box>
)
}