// with lock/hidden feature after entering pin sales amount can be viewed
// F:\medical-inventory\frontend\src\pages\Dashboard.tsx
// import { useMemo, useState } from 'react';
// import {
//   Grid,
//   Paper,
//   Typography,
//   Stack,
//   Dialog,
//   DialogTitle,
//   DialogContent,
//   DialogActions,
//   Table,
//   TableHead,
//   TableBody,
//   TableRow,
//   TableCell,
//   Tooltip,
//   Button,
//   TextField,
// } from '@mui/material';
// import { useQuery } from '@tanstack/react-query';
// import { listBills } from '../services/billing';
// import { listReturns } from '../services/returns';
// import { listItems } from '../services/inventory';
// import { todayRange } from '../lib/date';

// const LOW_STOCK_THRESH = 2;       // ≤ 2 is low-stock
// const EXPIRY_WINDOW_DAYS = 60;    // within next 60 days

// // Simple admin PIN (for now – later move to backend / env)
// const ADMIN_PIN = '4321';

// export default function Dashboard() {
//   const { from, to } = todayRange();

//   const [openLow, setOpenLow] = useState(false);
//   const [openExp, setOpenExp] = useState(false);

//   // privacy-lock state
//   const [privacyUnlocked, setPrivacyUnlocked] = useState(false);
//   const [pinDialogOpen, setPinDialogOpen] = useState(false);
//   const [pinValue, setPinValue] = useState('');
//   const [pinError, setPinError] = useState('');

//   const qBills = useQuery({
//     queryKey: ['dash-bills', from, to],
//     queryFn: () => listBills({ from_date: from, to_date: to, limit: 500 }),
//   });

//   const qReturns = useQuery({
//     queryKey: ['dash-returns', from, to],
//     queryFn: () => listReturns({ from_date: from, to_date: to, limit: 500 }),
//   });

//   const qInv = useQuery({
//     queryKey: ['dash-inventory'],
//     queryFn: () => listItems(''), // fetch all
//   });

//   // ---- Today’s Sales (use backend total_amount; source of truth) ----
//   const salesToday = useMemo(
//     () => ((qBills.data || []) as any[]).reduce((sum, b) => sum + Number(b.total_amount || 0), 0),
//     [qBills.data]
//   );

//   // ---- Returns (unchanged) ----
//   const todayRefunds = useMemo(() => {
//     const rets = (qReturns.data || []) as any[];
//     let total = 0;
//     for (const r of rets) {
//       if (typeof r.subtotal_return === 'number') total += r.subtotal_return;
//       else total += (r.items || []).reduce((s: number, it: any) => s + Number(it.mrp) * Number(it.quantity), 0);
//     }
//     return Math.round(total * 100) / 100;
//   }, [qReturns.data]);

//   // ---- Net sales (Sales - Returns) ----
//   const netSalesToday = useMemo(
//     () => salesToday - todayRefunds,
//     [salesToday, todayRefunds]
//   );

//   // ---- Low Stock ----
//   const { lowStockItems, lowStockCount } = useMemo(() => {
//     const items = (qInv.data || []) as any[];
//     const lows = items.filter((it: any) => Number(it.stock || 0) <= LOW_STOCK_THRESH);
//     return { lowStockItems: lows, lowStockCount: lows.length };
//   }, [qInv.data]);

//   // ---- Expiring Soon (≤ 60 days) ----
//   const { expiringSoonItems, expiringSoonCount } = useMemo(() => {
//     const items = (qInv.data || []) as any[];
//     const today = new Date();
//     // normalize to midnight to avoid TZ off-by-ones
//     today.setHours(0, 0, 0, 0);

//     function daysUntil(exp: string | null | undefined) {
//       if (!exp) return Infinity;
//       // assume "YYYY-MM-DD" or ISO; force local midnight to be safe
//       const d = new Date(String(exp).length <= 10 ? `${exp}T00:00:00` : String(exp));
//       if (isNaN(d.getTime())) return Infinity;
//       d.setHours(0, 0, 0, 0);
//       return Math.ceil((d.getTime() - today.getTime()) / 86400000);
//     }

//     const soon = items
//       .map((it: any) => {
//         const days = daysUntil(it.expiry_date);
//         return { ...it, _daysLeft: days };
//       })
//       .filter((it: any) => it._daysLeft >= 0 && it._daysLeft <= EXPIRY_WINDOW_DAYS)
//       .sort((a: any, b: any) => a._daysLeft - b._daysLeft); // closest first

//     return { expiringSoonItems: soon, expiringSoonCount: soon.length };
//   }, [qInv.data]);

//   // ---------- Privacy lock handlers ----------
//   const handleUnlockClick = () => {
//     setPinValue('');
//     setPinError('');
//     setPinDialogOpen(true);
//   };

//   const handleVerifyPin = () => {
//     if (pinValue === ADMIN_PIN) {
//       setPrivacyUnlocked(true);
//       setPinDialogOpen(false);
//     } else {
//       setPinError('Incorrect PIN');
//     }
//   };

//   const handleLock = () => {
//     setPrivacyUnlocked(false);
//   };

//   const moneyDisplay = (value: number) =>
//     privacyUnlocked ? `₹${value.toFixed(2)}` : '₹•••••';

//   return (
//     <Stack gap={2}>
//       {/* Header + privacy toggle */}
//       <Stack direction="row" alignItems="center" justifyContent="space-between">
//         <Typography variant="h5">Medical Inventory</Typography>
//         <Stack direction="row" spacing={1} alignItems="center">
//           <Typography variant="body2" color="text.secondary">
//             Privacy: {privacyUnlocked ? 'Unlocked' : 'Locked'}
//           </Typography>
//           {privacyUnlocked ? (
//             <Button size="small" variant="outlined" onClick={handleLock}>
//               Hide amounts
//             </Button>
//           ) : (
//             <Button size="small" variant="contained" onClick={handleUnlockClick}>
//               Show amounts
//             </Button>
//           )}
//         </Stack>
//       </Stack>

//       <Grid container spacing={2}>
//         {/* Today’s Sales */}
//         <Grid item xs={12} md={3}>
//           <Paper sx={{ p: 2 }}>
//             <Typography variant="subtitle2" color="text.secondary">
//               Today’s Sales
//             </Typography>
//             <Typography variant="h6">
//               {moneyDisplay(salesToday)}
//             </Typography>
//           </Paper>
//         </Grid>

//         {/* Returns */}
//         <Grid item xs={12} md={3}>
//           <Paper sx={{ p: 2 }}>
//             <Typography variant="subtitle2" color="text.secondary">
//               Returns
//             </Typography>
//             <Typography variant="h6">
//               {moneyDisplay(todayRefunds)}
//             </Typography>
//           </Paper>
//         </Grid>

//         {/* Net Sales */}
//         <Grid item xs={12} md={3}>
//           <Paper sx={{ p: 2 }}>
//             <Typography variant="subtitle2" color="text.secondary">
//               Net Sales
//             </Typography>
//             <Typography variant="h6">
//               {moneyDisplay(netSalesToday)}
//             </Typography>
//           </Paper>
//         </Grid>

//         {/* Low Stock */}
//         <Grid item xs={12} md={3}>
//           <Tooltip title="Click to view low stock details">
//             <Paper
//               sx={{ p: 2, cursor: 'pointer', '&:hover': { bgcolor: 'action.hover' } }}
//               onClick={() => setOpenLow(true)}
//             >
//               <Typography variant="subtitle2" color="text.secondary">
//                 Low Stock
//               </Typography>
//               <Typography variant="h5">{lowStockCount} items</Typography>
//             </Paper>
//           </Tooltip>
//         </Grid>

//         {/* Expiring Soon */}
//         <Grid item xs={12} md={3}>
//           <Tooltip title={`Items expiring within ${EXPIRY_WINDOW_DAYS} days`}>
//             <Paper
//               sx={{ p: 2, cursor: 'pointer', '&:hover': { bgcolor: 'action.hover' } }}
//               onClick={() => setOpenExp(true)}
//             >
//               <Typography variant="subtitle2" color="text.secondary">
//                 Expiring Soon
//               </Typography>
//               <Typography variant="h5">{expiringSoonCount} items</Typography>
//             </Paper>
//           </Tooltip>
//         </Grid>
//       </Grid>

//       {/* PIN dialog */}
//       <Dialog open={pinDialogOpen} onClose={() => setPinDialogOpen(false)}>
//         <DialogTitle>Unlock sensitive data</DialogTitle>
//         <DialogContent>
//           <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
//             Enter admin PIN to view today&apos;s sales, returns and net sales.
//           </Typography>
//           <TextField
//             autoFocus
//             margin="dense"
//             label="Admin PIN"
//             type="password"
//             fullWidth
//             value={pinValue}
//             onChange={(e) => {
//               setPinValue(e.target.value);
//               setPinError('');
//             }}
//             inputProps={{ maxLength: 6 }}
//             error={!!pinError}
//             helperText={pinError}
//           />
//         </DialogContent>
//         <DialogActions>
//           <Button onClick={() => setPinDialogOpen(false)}>Cancel</Button>
//           <Button onClick={handleVerifyPin} variant="contained">
//             Unlock
//           </Button>
//         </DialogActions>
//       </Dialog>

//       {/* Low Stock dialog */}
//       <Dialog open={openLow} onClose={() => setOpenLow(false)} fullWidth maxWidth="sm">
//         <DialogTitle>Low Stock Items (≤ {LOW_STOCK_THRESH})</DialogTitle>
//         <DialogContent>
//           {lowStockItems.length === 0 ? (
//             <Typography color="text.secondary" p={1}>
//               All items are sufficiently stocked.
//             </Typography>
//           ) : (
//             <Table size="small">
//               <TableHead>
//                 <TableRow>
//                   <TableCell>Name</TableCell>
//                   <TableCell>Brand</TableCell>
//                   <TableCell align="right">MRP</TableCell>
//                   <TableCell align="right">Stock</TableCell>
//                 </TableRow>
//               </TableHead>
//               <TableBody>
//                 {lowStockItems.map((it: any) => (
//                   <TableRow key={it.id}>
//                     <TableCell>{it.name}</TableCell>
//                     <TableCell>{it.brand || '-'}</TableCell>
//                     <TableCell align="right">{it.mrp}</TableCell>
//                     <TableCell align="right" sx={{ color: 'error.main' }}>
//                       {it.stock}
//                     </TableCell>
//                   </TableRow>
//                 ))}
//               </TableBody>
//             </Table>
//           )}
//           <Stack alignItems="flex-end" p={1}>
//             <Button onClick={() => setOpenLow(false)}>Close</Button>
//           </Stack>
//         </DialogContent>
//       </Dialog>

//       {/* Expiring Soon dialog */}
//       <Dialog open={openExp} onClose={() => setOpenExp(false)} fullWidth maxWidth="md">
//         <DialogTitle>Expiring Soon (≤ {EXPIRY_WINDOW_DAYS} days)</DialogTitle>
//         <DialogContent>
//           {expiringSoonItems.length === 0 ? (
//             <Typography color="text.secondary" p={1}>
//               No items expiring soon.
//             </Typography>
//           ) : (
//             <Table size="small">
//               <TableHead>
//                 <TableRow>
//                   <TableCell>Name</TableCell>
//                   <TableCell>Brand</TableCell>
//                   {/* Batch column removed */}
//                   <TableCell>Expiry</TableCell>
//                   <TableCell align="right">Days Left</TableCell>
//                 </TableRow>
//               </TableHead>
//               <TableBody>
//                 {expiringSoonItems.map((it: any) => (
//                   <TableRow key={it.id}>
//                     <TableCell>{it.name}</TableCell>
//                     <TableCell>{it.brand || '-'}</TableCell>
//                     {/* Batch cell removed */}
//                     <TableCell>{it.expiry_date || '-'}</TableCell>
//                     <TableCell align="right" sx={{ fontWeight: 600 }}>
//                       {it._daysLeft}
//                     </TableCell>
//                   </TableRow>
//                 ))}
//               </TableBody>
//             </Table>
//           )}
//           <Stack alignItems="flex-end" p={1}>
//             <Button onClick={() => setOpenExp(false)}>Close</Button>
//           </Stack>
//         </DialogContent>
//       </Dialog>
//     </Stack>
//   );
// }


































// F:\medical-inventory\frontend\src\pages\Dashboard.tsx
import { useMemo, useState } from 'react';
import {
  Grid, Paper, Typography, Stack, Dialog, DialogTitle, DialogContent,
  Table, TableHead, TableBody, TableRow, TableCell, Tooltip, Button
} from '@mui/material';
import { useQuery } from '@tanstack/react-query';
import { listBills } from '../services/billing';
import { listReturns } from '../services/returns';
import { listItems } from '../services/inventory';
import { todayRange } from '../lib/date';

const LOW_STOCK_THRESH = 2;       // ≤ 2 is low-stock
const EXPIRY_WINDOW_DAYS = 60;    // within next 60 days

export default function Dashboard() {
  const { from, to } = todayRange();

  const [openLow, setOpenLow] = useState(false);
  const [openExp, setOpenExp] = useState(false);

  const qBills = useQuery({
    queryKey: ['dash-bills', from, to],
    queryFn: () => listBills({ from_date: from, to_date: to, limit: 500 }),
  });

  const qReturns = useQuery({
    queryKey: ['dash-returns', from, to],
    queryFn: () => listReturns({ from_date: from, to_date: to, limit: 500 }),
  });

  const qInv = useQuery({
    queryKey: ['dash-inventory'],
    queryFn: () => listItems(''), // fetch all
  });

  // ---- Today’s Sales (use backend total_amount; source of truth) ----
  const salesToday = useMemo(
    () => ((qBills.data || []) as any[]).reduce((sum, b) => sum + Number(b.total_amount || 0), 0),
    [qBills.data]
  );

  // ---- Returns (unchanged) ----
  const todayRefunds = useMemo(() => {
    const rets = (qReturns.data || []) as any[];
    let total = 0;
    for (const r of rets) {
      if (typeof r.subtotal_return === 'number') total += r.subtotal_return;
      else total += (r.items || []).reduce((s: number, it: any) => s + Number(it.mrp) * Number(it.quantity), 0);
    }
    return Math.round(total * 100) / 100;
  }, [qReturns.data]);

  // ---- Low Stock ----
  const { lowStockItems, lowStockCount } = useMemo(() => {
    const items = (qInv.data || []) as any[];
    const lows = items.filter((it: any) => Number(it.stock || 0) <= LOW_STOCK_THRESH);
    return { lowStockItems: lows, lowStockCount: lows.length };
  }, [qInv.data]);

  // ---- Expiring Soon (≤ 60 days) ----
  const { expiringSoonItems, expiringSoonCount } = useMemo(() => {
    const items = (qInv.data || []) as any[];
    const today = new Date();
    // normalize to midnight to avoid TZ off-by-ones
    today.setHours(0, 0, 0, 0);

    function daysUntil(exp: string | null | undefined) {
      if (!exp) return Infinity;
      // assume "YYYY-MM-DD" or ISO; force local midnight to be safe
      const d = new Date(String(exp).length <= 10 ? `${exp}T00:00:00` : String(exp));
      if (isNaN(d.getTime())) return Infinity;
      d.setHours(0, 0, 0, 0);
      return Math.ceil((d.getTime() - today.getTime()) / 86400000);
    }

    const soon = items
      .map((it: any) => {
        const days = daysUntil(it.expiry_date);
        return { ...it, _daysLeft: days };
      })
      .filter((it: any) => it._daysLeft >= 0 && it._daysLeft <= EXPIRY_WINDOW_DAYS)
      .sort((a: any, b: any) => a._daysLeft - b._daysLeft); // closest first

    return { expiringSoonItems: soon, expiringSoonCount: soon.length };
  }, [qInv.data]);

  return (
    <Stack gap={2}>
      <Typography variant="h5">Medical Inventory</Typography>

      <Grid container spacing={2}>
        <Grid item xs={12} md={3}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="subtitle2" color="text.secondary">Today’s Sales</Typography>
            <Typography variant="h6">₹{salesToday.toFixed(2)}</Typography>
          </Paper>
        </Grid>

        <Grid item xs={12} md={3}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="subtitle2" color="text.secondary">Returns</Typography>
            <Typography variant="h5">₹{todayRefunds.toFixed(2)}</Typography>
          </Paper>
        </Grid>

        <Grid item xs={12} md={3}>
          <Tooltip title="Click to view low stock details">
            <Paper
              sx={{ p: 2, cursor: 'pointer', '&:hover': { bgcolor: 'action.hover' } }}
              onClick={() => setOpenLow(true)}
            >
              <Typography variant="subtitle2" color="text.secondary">Low Stock</Typography>
              <Typography variant="h5">{lowStockCount} items</Typography>
            </Paper>
          </Tooltip>
        </Grid>

        <Grid item xs={12} md={3}>
          <Tooltip title={`Items expiring within ${EXPIRY_WINDOW_DAYS} days`}>
            <Paper
              sx={{ p: 2, cursor: 'pointer', '&:hover': { bgcolor: 'action.hover' } }}
              onClick={() => setOpenExp(true)}
            >
              <Typography variant="subtitle2" color="text.secondary">Expiring Soon</Typography>
              <Typography variant="h5">{expiringSoonCount} items</Typography>
            </Paper>
          </Tooltip>
        </Grid>
      </Grid>

      {/* Low Stock dialog */}
      <Dialog open={openLow} onClose={() => setOpenLow(false)} fullWidth maxWidth="sm">
        <DialogTitle>Low Stock Items (≤ {LOW_STOCK_THRESH})</DialogTitle>
        <DialogContent>
          {lowStockItems.length === 0 ? (
            <Typography color="text.secondary" p={1}>All items are sufficiently stocked.</Typography>
          ) : (
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Name</TableCell>
                  <TableCell>Brand</TableCell>
                  <TableCell align="right">MRP</TableCell>
                  <TableCell align="right">Stock</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {lowStockItems.map((it: any) => (
                  <TableRow key={it.id}>
                    <TableCell>{it.name}</TableCell>
                    <TableCell>{it.brand || '-'}</TableCell>
                    <TableCell align="right">{it.mrp}</TableCell>
                    <TableCell align="right" sx={{ color: 'error.main' }}>{it.stock}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
          <Stack alignItems="flex-end" p={1}>
            <Button onClick={() => setOpenLow(false)}>Close</Button>
          </Stack>
        </DialogContent>
      </Dialog>

      {/* Expiring Soon dialog */}
      <Dialog open={openExp} onClose={() => setOpenExp(false)} fullWidth maxWidth="md">
        <DialogTitle>Expiring Soon (≤ {EXPIRY_WINDOW_DAYS} days)</DialogTitle>
        <DialogContent>
          {expiringSoonItems.length === 0 ? (
            <Typography color="text.secondary" p={1}>No items expiring soon.</Typography>
          ) : (
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Name</TableCell>
                  <TableCell>Brand</TableCell>
                  {/* Batch column removed */}
                  <TableCell>Expiry</TableCell>
                  <TableCell align="right">Days Left</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {expiringSoonItems.map((it: any) => (
                  <TableRow key={it.id}>
                    <TableCell>{it.name}</TableCell>
                    <TableCell>{it.brand || '-'}</TableCell>
                    {/* Batch cell removed */}
                    <TableCell>{it.expiry_date || '-'}</TableCell>
                    <TableCell align="right" sx={{ fontWeight: 600 }}>
                      {it._daysLeft}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
          <Stack alignItems="flex-end" p={1}>
            <Button onClick={() => setOpenExp(false)}>Close</Button>
          </Stack>
        </DialogContent>
      </Dialog>
    </Stack>
  );
}

