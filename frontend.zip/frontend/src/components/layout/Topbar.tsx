import { AppBar, Toolbar, Typography, Box } from '@mui/material'


export default function Topbar() {
return (
<AppBar position="sticky" elevation={0} color="inherit" sx={{ borderBottom: '1px solid #eee' }}>
<Toolbar>
<Typography variant="h6" sx={{ flexGrow: 1 }}>Medical Inventory</Typography>
<Box fontSize={12} color="text.secondary">{new Date().toLocaleString()}</Box>
</Toolbar>
</AppBar>
)
}