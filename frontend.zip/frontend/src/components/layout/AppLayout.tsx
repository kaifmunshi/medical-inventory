import { Box } from '@mui/material'
import { Outlet } from 'react-router-dom'
import Sidebar from './Sidebar'
import Topbar from './Topbar'


export default function AppLayout() {
return (
<Box display="flex" minHeight="100vh">
<Sidebar />
<Box flex={1} display="flex" flexDirection="column">
<Topbar />
<Box component="main" p={2}>
<Outlet />
</Box>
</Box>
</Box>
)
}