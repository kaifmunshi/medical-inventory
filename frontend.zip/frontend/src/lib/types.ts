export type ID = number


export interface Item {
id: ID
name: string
brand?: string | null
expiry_date?: string | null // YYYY-MM-DD
mrp: number
stock: number
created_at?: string
updated_at?: string
}


export interface BillItemIn { item_id: ID; quantity: number; mrp: number }
export interface BillCreate {
items: BillItemIn[]
discount_percent?: number
tax_percent?: number
payment_mode: 'cash' | 'online' | 'split'
payment_cash?: number
payment_online?: number
notes?: string
}