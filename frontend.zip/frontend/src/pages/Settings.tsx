import { Typography } from '@mui/material'
export default function Settings(){
return <Typography variant="h5">Settings</Typography>
}